# 🌐FiveM-Icons-Pack

## ℹ️ Hey, this is a FiveM Notification Pack, where you can change every Notification. Also, it replace the hud.

## 🛠️How to change notification icon:
1. Open OpenIV with "Edit mode"
2. Go to the file, replace the file with a 64x64px picture and save the file

![image](https://user-images.githubusercontent.com/60815764/143658075-152b832c-a4dd-4dea-9e01-3152b5ba079f.png)
## ❗If you want to add new icons, just copy any file (.ytd) and rename the file and the texture!

[Notification list](https://wiki.rage.mp/index.php?title=Notification_Pictures)

![image](https://user-images.githubusercontent.com/60815764/143658209-c13d5c78-6766-4d5a-836f-70e5a360dea6.png)

## 🔧Installation:
1. Put in the /resource folder
2. Start in the server.cfg
