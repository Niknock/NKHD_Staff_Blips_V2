fx_version 'cerulean'
game 'gta5'

author 'Niknock HD'
description 'Notification Pictures'
version '1.0.0'
